using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using Photon.Pun;

public class PlayerManager : MonoBehaviourPun
{
    GameManager gameManager;
    PlayerSwampSite playerSwampSite;
    PlayerInput playerInput;
    

    [SerializeField] List<GameObject> treeListP1 = new List<GameObject>();
    [SerializeField] List<GameObject> treeListP2 = new List<GameObject>();
    [SerializeField] List<GameObject> treeListP3 = new List<GameObject>();
    [SerializeField] List<GameObject> treeListP4 = new List<GameObject>();
    List<List<GameObject>> listGameObjectOfList = new List<List<GameObject>>();

    GameObject branchPrefab;
    GameObject treePrefab;

    [SerializeField] private int playerID;
    public bool playerGameOver = false;

    [SerializeField] int[] randomRangeTable;
    [SerializeField] InputActionReference actionReference;

    [SerializeField] GameObject endGameUI;

    private void Awake()
    {
        endGameUI.SetActive(false);

        // Initialize 
        gameManager = GameManager.instance;
        this.treePrefab = gameManager.treePrefab;
        this.branchPrefab = gameManager.branchPrefab;

        // Pos tree / respawn Tree 
        playerID = PhotonNetwork.LocalPlayer.ActorNumber;

        // Create number for branch
        randomRangeTable = new int[gameManager.countTree];

    }
    void Start()
    {
        if (PhotonNetwork.CurrentRoom.PlayerCount == 0)
            return;

        if (photonView.IsMine)
        {
            object value;
            if (PhotonNetwork.CurrentRoom.CustomProperties.TryGetValue("rb", out value))
            {
                randomRangeTable = (int[])value;

                Debug.Log(randomRangeTable.Length);
            }
        }

        // Player Input (Add event itp.)
        playerInput = GetComponent<PlayerInput>();
        playerSwampSite = GetComponent<PlayerSwampSite>();  
        playerInput.actionEvents[0].AddListener(HittingTree);

        if (photonView.IsMine)
        {
            listGameObjectOfList.Add(treeListP1);
            listGameObjectOfList.Add(treeListP2);
            listGameObjectOfList.Add(treeListP3);
            listGameObjectOfList.Add(treeListP4);
        }

        photonView.RPC("CreateTree", RpcTarget.AllBuffered, gameManager.treePositionVec2[playerID - 1].x, playerID);

    }

    [PunRPC]
    public void CreateTree(float spawnOnX, int playerID) 
    {
        Debug.Log("Func 'Create Tree' playerID = " + playerID);
        if(!photonView.IsMine)
        {
            return;
        }

        for (int i = 0; i < gameManager.countTree; i++)
        {
            GameObject currentTree = Instantiate(treePrefab,new Vector3(spawnOnX, i + 1,0),Quaternion.identity);

            if(playerID == 1)
            {
                treeListP1.Add(currentTree);
            }
            else if(playerID == 2)
            {
                treeListP2.Add(currentTree);
            }
            else if(playerID == 3)
            {
                treeListP3.Add(currentTree);
            }
            else if (playerID == 4)
            {
                treeListP4.Add(currentTree);
            }
        }
        
        SyncBranch(playerID);
    }

    public void SyncBranch(int playerID)
    {
        List<GameObject> treeList = listGameObjectOfList[playerID - 1];
        for (int i = 0; i < treeList.Count; i++)
        {
            Instantiate(branchPrefab, new Vector2(treeList[i].transform.position.x + randomRangeTable[i], treeList[i].transform.position.y), Quaternion.identity, treeList[i].transform);
        }


    }
    public void HittingTree(InputAction.CallbackContext hit)
    {
        if(!gameManager.isGameStart || playerGameOver)
        { 
            return;
        }

        if (hit.action.triggered)
        {

            if(photonView.IsMine)
            {
                Debug.Log("hit");


                object value;
                if (PhotonNetwork.LocalPlayer.CustomProperties.TryGetValue(TIMBER_MULTIPLAYER.PLAYER_SWAMP_SIDE, out value))
                {
                    Vector2[] list = (Vector2[])value;
                    Vector2 leftSite = list[0];
                    Vector2 rightSite = list[1];

                    playerSwampSite.SwampPos(hit.control, leftSite, rightSite);
                }


                photonView.RPC("MultiplyScore", RpcTarget.AllBuffered, 1);


            }          
            photonView.RPC("HitTree", RpcTarget.AllBuffered, playerID);
        }


    }
    [PunRPC]
    public void HitTree(int playerID)
    {
        Debug.Log("Heloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo === " + listGameObjectOfList.Count);

        for (int i = 1; i <= PhotonNetwork.CurrentRoom.PlayerCount; i++)
        {
            if (playerID == i)
            {

                List<GameObject> obj = listGameObjectOfList[i - 1];

                for (int j = obj.Count - 1; j > 0; j--)
                {
                    obj[j].transform.position = obj[j - 1].transform.position;
                }

                Destroy(obj[0].gameObject);

                obj.Remove(obj[0]);
            }
        }
    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Branch"))
        {
            if(photonView.IsMine)
                photonView.RPC("TurnUI", RpcTarget.All);
        }

        Debug.Log("Collision with " + collision.name);
    }
    [PunRPC]
    private void TurnUI()
    {
        playerGameOver = true;

        if (endGameUI == null)
            return;

        endGameUI.SetActive(true);
        endGameUI.GetComponent<Text>().text = "Przegra� gracz o nicku : " + PhotonNetwork.LocalPlayer.NickName;

    }
}
